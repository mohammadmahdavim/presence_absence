<label>روز </label>

<select  class="js-example-basic-single" multiple dir="rtl" name="day[]">

    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option
            <?php if(isset(request()->day) && is_array(request()->day) && in_array($day->id, request()->day)): ?> selected <?php endif; ?>
            value="<?php echo e($day->id); ?>"><?php echo e($day->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH D:\laragon\www\BookFair\resources\views/components/day.blade.php ENDPATH**/ ?>
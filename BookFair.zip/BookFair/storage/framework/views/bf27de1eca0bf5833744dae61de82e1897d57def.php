<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h3>داشبورد</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">داشبورد</a></li>
                    <li class="breadcrumb-item active" aria-current="page">پیش فرض</li>
                </ol>
            </nav>
        </div>
    </div>
    <h3>مدیران</h3>

    <div class="row">
        <form action="/manager-import" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input name="import_file" type="file" required>
            <button class="btn btn-success btn-block">ارسال</button>
        </form>
    </div>
    <br>
    <hr>
    <br>
    <h3>کارمندان</h3>
    <div class="row">
        <form action="/personnel-import" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input name="import_file" type="file" required>
            <button class="btn btn-success btn-block">ارسال</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\BookFair\resources\views/panel/import.blade.php ENDPATH**/ ?>
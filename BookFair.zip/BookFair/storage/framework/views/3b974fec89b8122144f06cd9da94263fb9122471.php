<label>غرفه </label>

<select  class="js-example-basic-single" multiple dir="rtl" name="loge[]">

    <?php $__currentLoopData = $loges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option
            <?php if(isset(request()->loge) && is_array(request()->loge) && in_array($loge->id, request()->loge)): ?> selected <?php endif; ?>

        value="<?php echo e($loge->id); ?>"><?php echo e($loge->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH D:\laragon\www\BookFair\resources\views/components/loge.blade.php ENDPATH**/ ?>
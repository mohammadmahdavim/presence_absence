

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="/assets/vendors/select2/css/select2.min.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h3>
                <?php echo e(isset($personnel) ? 'ویرایش' : 'ثبت جدید'); ?>

            </h3>
            <nav aria-label="breadcrumb">

            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex align-items-center">
                        <h5 class="m-b-0">
                            <?php echo e(isset($personnel) ? ' ویرایش ' . $personnel->name  : 'ثبت فرد جدید'); ?>

                        </h5>
                    </div>
                    <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(isset($personnel) ? '/personnel/'.$personnel->id.'/update':'/personnel/store'); ?>"
                          method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-4 form-group">
                                <label for="">نام و نام خانوادگی</label>
                                <input class="form-control" name="name" value="<?php echo e(($personnel->name) ?? old('name')); ?>">
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="">کد ملی</label>
                                <input type="number" class="form-control" name="national_code"
                                       value="<?php echo e(($personnel->national_code) ?? old('national_code')); ?>">
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="">موبایل</label>
                                <input type="number" class="form-control" name="mobile"
                                       value="<?php echo e(($personnel->mobile) ?? old('mobile')); ?>">
                            </div>
                            <div class="col-md-2 form-group">
                                <label for="">تایم</label>
                                <select class="form-control" name="is_full_time">
                                    <option value="0">پاره وقت</option>
                                    <option
                                        value="1" <?php echo e((($personnel->is_full_time ?? old('is_full_time')) == 1) ? 'selected':''); ?>>
                                        تمام وقت
                                    </option>
                                </select>
                            </div>
                            <div class="col-md-2 form-group">
                                <label for="">بخش</label>
                                <select class="form-control" name="section_id">
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($key); ?>" <?php echo e((($personnel->section_id ?? old('section_id')) == $key) ? 'selected':''); ?>>
                                            <?php echo e($section); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2 form-group">
                                <label for="">مدیر</label>
                                <select class="form-control" name="manager_id">
                                    <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($key); ?>" <?php echo e((($personnel->manager_id ?? old('manager_id')) == $key) ? 'selected':''); ?>>
                                            <?php echo e($manager); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2 form-group">
                                <label for="">منطقه</label>
                                <select class="form-control" name="area_id">
                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($key); ?>" <?php echo e((($personnel->area_id ?? old('area_id') == $key)) ? 'selected':''); ?>>
                                            <?php echo e($area); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2 form-group">
                                <label for="">نقش</label>
                                <select class="form-control" name="role_id">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($key); ?>" <?php echo e((($personnel->role_id ?? old('role_id')) == $key) ? 'selected':''); ?>>
                                            <?php echo e($role); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2 form-group">
                                <label for="">منبع پرداخت</label>
                                <select class="form-control" name="payment_source_id">
                                    <?php $__currentLoopData = $paymentSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$paymentSource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($key); ?>" <?php echo e((($personnel->payment_source_id ?? old('payment_source_id')) == $key) ? 'selected':''); ?>>
                                            <?php echo e($paymentSource); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2 form-group">
                                <label for="">غرفه</label>
                                <select class="form-control" name="loge_id">
                                    <?php $__currentLoopData = $loges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$loge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($key); ?>" <?php echo e((($personnel->loge_id ?? old('loge_id')) == $key) ? 'selected':''); ?>>
                                            <?php echo e($loge); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-12 form-group">
                                <label for="">پیش بینی حضور</label>
                                <select class="js-example-basic-single" name="forecast[]" multiple dir="rtl">
                                    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($key); ?>" <?php echo e(in_array($key,($forecasts ?? old('forecast')) ?? []) ? 'selected':''); ?>><?php echo e($day); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4 form-group"></div>
                            <div class="col-md-4 form-group">
                                <button type="submit" class="btn btn-success btn-block text-white">
                                    ثبت
                                </button>
                            </div>
                            <div class="col-md-4 form-group"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="/assets/vendors/select2/js/select2.min.js"></script>
    <script src="/assets/js/examples/select2.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\BookFair\resources\views/panel/personnel/create.blade.php ENDPATH**/ ?>
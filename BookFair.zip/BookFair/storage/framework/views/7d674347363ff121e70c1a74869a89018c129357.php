<label>بخش </label>

<select class="js-example-basic-single" multiple dir="rtl" name="section[]">

    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option
            <?php if(isset(request()->section) && is_array(request()->section) && in_array($section->id, request()->section)): ?> selected <?php endif; ?>

        value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH D:\laragon\www\BookFair\resources\views/components/section.blade.php ENDPATH**/ ?>
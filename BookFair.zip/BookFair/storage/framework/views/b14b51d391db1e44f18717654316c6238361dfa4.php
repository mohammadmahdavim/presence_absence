<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="/assets/vendors/dataTable/responsive.bootstrap.min.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h3>
                لیست پرسنل
            </h3>
            <nav aria-label="breadcrumb">

            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex align-items-center">
                        <h5 class="m-b-0">
                            لیست کل پرسنل در نمایشگاه کتاب
                        </h5>
                    </div>
                    <table id="personnel-table" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>نام</th>
                            <th>کد ملی</th>
                            <th>موبایل</th>
                            <th>نقش</th>
                            <th>بخش</th>
                            <th>عملیات</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $personnel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->name); ?></td>
                                <td><?php echo e($row->national_code); ?></td>
                                <td><?php echo e($row->mobile); ?></td>
                                <td><?php echo e($row->role->name); ?></td>
                                <td><?php echo e($row->section->name); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <a class="btn btn-outline-primary btn-sm" href="#" data-toggle="dropdown"
                                           aria-haspopup="true" aria-expanded="false">
                                            <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                        </a>
                                        <div class="dropdown-menu">
                                            <a href="/personnel/<?php echo e($row->id); ?>/edit" class="dropdown-item">ویرایش</a>
                                            <?php if (isset($component)) { $__componentOriginala1ba9590a4592b62763514a951d56f103b715d1d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Destroy::class, ['id' => $row->id,'url' => '\'/personnel/destroy\'']); ?>
<?php $component->withName('destroy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1ba9590a4592b62763514a951d56f103b715d1d)): ?>
<?php $component = $__componentOriginala1ba9590a4592b62763514a951d56f103b715d1d; ?>
<?php unset($__componentOriginala1ba9590a4592b62763514a951d56f103b715d1d); ?>
<?php endif; ?>

                                            <a href="/personnel/cart/<?php echo e($row->id); ?>" class="dropdown-item">کارت</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="/js/sweet.js"></script>

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- begin::dataTable -->
    <script src="/assets/vendors/dataTable/jquery.dataTables.min.js"></script>
    <script src="/assets/vendors/dataTable/dataTables.bootstrap4.min.js"></script>
    <script src="/assets/vendors/dataTable/dataTables.responsive.min.js"></script>
    <script src="/assets/js/examples/datatable.js"></script>
    <!-- end::dataTable -->
    <script>
        $('#personnel-table').DataTable({
            responsive: true,
            language: {
                "sEmptyTable": "هیچ داده ای در جدول وجود ندارد",
                "sInfo": "نمایش _START_ تا _END_ از _TOTAL_ رکورد",
                "sInfoEmpty": "نمایش 0 تا 0 از 0 رکورد",
                "sInfoFiltered": "(فیلتر شده از _MAX_ رکورد)",
                "sInfoPostFix": "",
                "sInfoThousands": ",",
                "sLengthMenu": "نمایش _MENU_ رکورد",
                "sLoadingRecords": "در حال بارگزاری...",
                "sProcessing": "در حال پردازش...",
                "sSearch": "جستجو:",
                "sZeroRecords": "رکوردی با این مشخصات پیدا نشد",
                "oPaginate": {
                    "sFirst": "ابتدا",
                    "sLast": "انتها",
                    "sNext": "بعدی",
                    "sPrevious": "قبلی"
                },
                "oAria": {
                    "sSortAscending": ": فعال سازی نمایش به صورت صعودی",
                    "sSortDescending": ": فعال سازی نمایش به صورت نزولی"
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\BookFair\resources\views/panel/personnel/list.blade.php ENDPATH**/ ?>
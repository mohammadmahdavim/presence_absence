<?php $__env->startSection('head'); ?>

    <link rel="stylesheet" href="/assets/vendors/select2/css/select2.min.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h3>گزارشات</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">میزکار</a></li>
                    <li class="breadcrumb-item active" aria-current="page">گزارش کل</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-row">
                        <div class="p-2">
                            <button type='button' class="btn btn-primary" onclick="hideshow()" id='hideshow'>
                                جستجوی پیشرفته
                            </button>
                        </div>
                        <div class="p-2">

                            <form method="get" action="/reportAll/export">
                                <input hidden name="code" value="<?php echo e(request()->code); ?>">
                                <input hidden name="name" value="<?php echo e(request()->name); ?>">
                                <?php if(request()->day): ?>
                                    <select hidden name="groups[]" multiple="multiple">
                                        <?php $__currentLoopData = request()->day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option selected><?php echo e($day_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if(request()->loge): ?>
                                    <select hidden name="loge[]" multiple="multiple">
                                        <?php $__currentLoopData = request()->loge; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loge_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option selected><?php echo e($loge_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if(request()->section): ?>
                                    <select hidden name="section[]" multiple="multiple">
                                        <?php $__currentLoopData = request()->section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option selected><?php echo e($section_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if(request()->payment): ?>
                                    <select hidden name="payment[]" multiple="multiple">
                                        <?php $__currentLoopData = request()->payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option selected><?php echo e($payment_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>


                                <button type='submit' class="btn btn-danger">
                                    دریافت فایل
                                </button>
                            </form>
                        </div>


                    </div>
                    <div id='search' style="display: none">
                        <form method="get" action="/reportAll">

                            <div class="row">
                                <div class="col-md-2">
                                    <label>کد</label>

                                    <input class="form-control" id="code" name="code" autocomplete="off"
                                           value="<?php echo e(request()->code); ?>"
                                           placeholder="کد">
                                </div>
                                <div class="col-md-2">
                                    <label>نام</label>

                                    <input class="form-control" id="name" name="name" autocomplete="off"
                                           value="<?php echo e(request()->name); ?>"
                                           placeholder="نام">
                                </div>

                                <div class="col-md-2">
                                    <?php if (isset($component)) { $__componentOriginal43380c084db75f4385220f30b02734f2395033f7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Loge::class, []); ?>
<?php $component->withName('Loge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43380c084db75f4385220f30b02734f2395033f7)): ?>
<?php $component = $__componentOriginal43380c084db75f4385220f30b02734f2395033f7; ?>
<?php unset($__componentOriginal43380c084db75f4385220f30b02734f2395033f7); ?>
<?php endif; ?>

                                </div>

                                <div class="col-md-2">
                                    <?php if (isset($component)) { $__componentOriginal853b6d9076946f0151e144f59030679842dc3ef3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Section::class, []); ?>
<?php $component->withName('Section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal853b6d9076946f0151e144f59030679842dc3ef3)): ?>
<?php $component = $__componentOriginal853b6d9076946f0151e144f59030679842dc3ef3; ?>
<?php unset($__componentOriginal853b6d9076946f0151e144f59030679842dc3ef3); ?>
<?php endif; ?>

                                </div>
                                <div class="col-md-2">
                                    <?php if (isset($component)) { $__componentOriginal641f81b69a265e38ea849a4e8e7658167b839d47 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Payment::class, []); ?>
<?php $component->withName('Payment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal641f81b69a265e38ea849a4e8e7658167b839d47)): ?>
<?php $component = $__componentOriginal641f81b69a265e38ea849a4e8e7658167b839d47; ?>
<?php unset($__componentOriginal641f81b69a265e38ea849a4e8e7658167b839d47); ?>
<?php endif; ?>

                                </div>

                                <div class="col-md-2">
                                    <br>
                                    <button type="submit" class="btn btn-info">جستجوکن</button>
                                </div>
                            </div>


                        </form>
                    </div>
                    <br>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                            <tr style="text-align: center">
                                <th>کد</th>
                                <th>نام</th>
                                <th>کدملی</th>
                                <th>موبایل</th>
                                <th>نقش</th>
                                <th>غرفه</th>
                                <th>بخش</th>
                                <th>منطقه</th>
                                <th>منبع پرداخت</th>
                                <th>تعداد روز</th>
                                <th>جمع ساعت</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($row->code); ?></td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->national_code); ?></td>
                                    <td><?php echo e($row->mobile); ?></td>
                                    <td><?php echo e($row->role->name); ?></td>
                                    <td><?php echo e($row->loge->name); ?></td>
                                    <td><?php echo e($row->section->name); ?></td>
                                    <td><?php echo e($row->area->name); ?></td>
                                    <td><?php echo e($row->payment->name); ?></td>
                                    <td><?php echo e($row->presence_count); ?></td>
                                    <td><?php echo e(floor($row->presence_sum_sum/60)); ?>:<?php echo e(fmod($row->presence_sum_sum,60)); ?>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo $rows->links("pagination::bootstrap-4"); ?>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- begin::select2 -->
    <script src="/assets/vendors/select2/js/select2.min.js"></script>
    <script src="/assets/js/examples/select2.js"></script>
    <!-- end::select2 -->
    <script>
        function hideshow() {
            var x = document.getElementById("search");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\BookFair\resources\views/panel/report/all.blade.php ENDPATH**/ ?>
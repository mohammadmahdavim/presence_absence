

<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <img class="m-b-50 img-fluid" src="/assets/media/image/404.png" alt="">
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <h2 class="font-weight-800 m-b-20"><?php echo e($text); ?></h2>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\BookFair\resources\views/errors/404.blade.php ENDPATH**/ ?>
<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="/assets/vendors/select2/css/select2.min.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h3>گزارشات</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">میزکار</a></li>
                    <li class="breadcrumb-item active" aria-current="page">گزارش ورود و خروج ها</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-row">
                        <div class="p-2">
                            <button type='button' class="btn btn-primary" onclick="hideshow()" id='hideshow'>
                                جستجوی پیشرفته
                            </button>
                        </div>
                        <div class="p-2">

                            <form method="get" action="/reportDetail/export">
                                <input hidden name="code" value="<?php echo e(request()->code); ?>">
                                <input hidden name="name" value="<?php echo e(request()->name); ?>">
                                <?php if(request()->day): ?>
                                    <select hidden name="groups[]" multiple="multiple">
                                        <?php $__currentLoopData = request()->day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option selected><?php echo e($day_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if(request()->day): ?>
                                    <select hidden name="day[]" multiple="multiple">
                                        <?php $__currentLoopData = request()->day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option selected><?php echo e($day_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if(request()->loge): ?>
                                    <select hidden name="loge[]" multiple="multiple">
                                        <?php $__currentLoopData = request()->loge; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loge_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option selected><?php echo e($loge_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if(request()->section): ?>
                                    <select hidden name="section[]" multiple="multiple">
                                        <?php $__currentLoopData = request()->section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option selected><?php echo e($section_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if(request()->payment): ?>
                                    <select hidden name="payment[]" multiple="multiple">
                                        <?php $__currentLoopData = request()->payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option selected><?php echo e($payment_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>


                                <button type='submit' class="btn btn-danger">
                                    دریافت فایل
                                </button>
                            </form>
                        </div>


                    </div>
                    <div id='search' style="display: none">
                        <form method="get" action="/reportDetail">

                            <div class="row">
                                <div class="col-md-2 form-group">
                                    <label>کد</label>

                                    <input class="form-control" id="code" name="code" autocomplete="off"
                                           value="<?php echo e(request()->code); ?>"
                                           placeholder="کد">
                                </div>
                                <div class="col-md-2 form-group">
                                    <label>نام</label>

                                    <input class="form-control" id="name" name="name" autocomplete="off"
                                           value="<?php echo e(request()->name); ?>"
                                           placeholder="نام">
                                </div>

                                <div class="col-md-2 form-group">
                                    <?php if (isset($component)) { $__componentOriginal43380c084db75f4385220f30b02734f2395033f7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Loge::class, []); ?>
<?php $component->withName('Loge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43380c084db75f4385220f30b02734f2395033f7)): ?>
<?php $component = $__componentOriginal43380c084db75f4385220f30b02734f2395033f7; ?>
<?php unset($__componentOriginal43380c084db75f4385220f30b02734f2395033f7); ?>
<?php endif; ?>

                                </div>

                                <div class="col-md-2 form-group">
                                    <?php if (isset($component)) { $__componentOriginal853b6d9076946f0151e144f59030679842dc3ef3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Section::class, []); ?>
<?php $component->withName('Section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal853b6d9076946f0151e144f59030679842dc3ef3)): ?>
<?php $component = $__componentOriginal853b6d9076946f0151e144f59030679842dc3ef3; ?>
<?php unset($__componentOriginal853b6d9076946f0151e144f59030679842dc3ef3); ?>
<?php endif; ?>

                                </div>
                                <div class="col-md-2 form-group">
                                    <?php if (isset($component)) { $__componentOriginal641f81b69a265e38ea849a4e8e7658167b839d47 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Payment::class, []); ?>
<?php $component->withName('Payment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal641f81b69a265e38ea849a4e8e7658167b839d47)): ?>
<?php $component = $__componentOriginal641f81b69a265e38ea849a4e8e7658167b839d47; ?>
<?php unset($__componentOriginal641f81b69a265e38ea849a4e8e7658167b839d47); ?>
<?php endif; ?>

                                </div>
                                <div class="col-md-2 form-group">
                                    <?php if (isset($component)) { $__componentOriginale3f06676dae02740d4522eb7555531a7ac0ccafe = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Day::class, []); ?>
<?php $component->withName('Day'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3f06676dae02740d4522eb7555531a7ac0ccafe)): ?>
<?php $component = $__componentOriginale3f06676dae02740d4522eb7555531a7ac0ccafe; ?>
<?php unset($__componentOriginale3f06676dae02740d4522eb7555531a7ac0ccafe); ?>
<?php endif; ?>

                                </div>
                                <div class="col-md-2 form-group">
                                    <br>
                                    <button type="submit" class="btn btn-info">جستجوکن</button>
                                </div>
                            </div>


                        </form>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered" id="detail-table">
                            <thead>
                            <tr style="text-align: center">
                                <th>کد</th>
                                <th>نام</th>
                                <th>کدملی</th>
                                <th>موبایل</th>
                                <th>نقش</th>
                                <th>غرفه</th>
                                <th>بخش</th>
                                <th>منطقه</th>
                                <th>منبع پرداخت</th>
                                <th>روز</th>
                                <th>ورود</th>
                                <th>خروج</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($row->personnel->code); ?></td>
                                    <td><?php echo e($row->personnel->name); ?></td>
                                    <td><?php echo e($row->personnel->national_code); ?></td>
                                    <td><?php echo e($row->personnel->mobile); ?></td>
                                    <td><?php echo e($row->personnel->role->name); ?></td>
                                    <td><?php echo e($row->personnel->loge->name); ?></td>
                                    <td><?php echo e($row->personnel->section->name); ?></td>
                                    <td><?php echo e($row->personnel->area->name); ?></td>
                                    <td><?php echo e($row->personnel->payment->name); ?></td>
                                    <td><?php echo e($row->day->name); ?></td>
                                    <td><?php echo e($row->enter); ?></td>
                                    <td><?php echo e($row->exit); ?></td>
                                    <td class="">
                                        <div class="dropdown">
                                            <a class="btn btn-outline-primary btn-sm" href="#" data-toggle="dropdown"
                                               aria-haspopup="true" aria-expanded="false">
                                                <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                            </a>
                                            <div class="dropdown-menu">
                                                <a onclick="modalShow('/attendance/<?php echo e($row->id); ?>/edit');"
                                                   class="dropdown-item">ویرایش</a>
                                                <?php if (isset($component)) { $__componentOriginala1ba9590a4592b62763514a951d56f103b715d1d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Destroy::class, ['id' => $row->id,'url' => '\'/attendance/delete\'']); ?>
<?php $component->withName('destroy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala1ba9590a4592b62763514a951d56f103b715d1d)): ?>
<?php $component = $__componentOriginala1ba9590a4592b62763514a951d56f103b715d1d; ?>
<?php unset($__componentOriginala1ba9590a4592b62763514a951d56f103b715d1d); ?>
<?php endif; ?>

                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo $rows->links("pagination::bootstrap-4"); ?>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('include.modal-show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="/js/sweet.js"></script>

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- begin::select2 -->
    <script src="/assets/vendors/select2/js/select2.min.js"></script>
    <script src="/assets/js/examples/select2.js"></script>
    <!-- end::select2 -->

    <script>
        function hideshow() {
            var x = document.getElementById("search");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }

        $('#modal-show').on('shown.bs.modal', function (e) {
            $('.clockpicker-autoclose-demo').clockpicker({
                autoclose: true,
                align: 'right'
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\BookFair\resources\views/panel/report/detail.blade.php ENDPATH**/ ?>
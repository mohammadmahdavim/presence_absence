<label>مالی </label>

<select class="js-example-basic-single" multiple dir="rtl" name="payment[]">

    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option
            <?php if(isset(request()->payment) && is_array(request()->payment) && in_array($payment->id, request()->payment)): ?> selected <?php endif; ?>

        value="<?php echo e($payment->id); ?>"><?php echo e($payment->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH D:\laragon\www\BookFair\resources\views/components/payment.blade.php ENDPATH**/ ?>
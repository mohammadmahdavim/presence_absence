<?php $__env->startSection('content'); ?>

    <!-- begin::page header -->
    <div class="page-header">
        <div>
            <h3>تغییر رمز</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">پروفایل</a></li>
                    <li class="breadcrumb-item active" aria-current="page">رمز</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- end::page header -->

    <div class="row">
        <div class="col-md-12">

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">
                        تغییر رمز
                    </h5>

                    <form action="/profile/password/<?php echo e(auth()->user()->id); ?>">

                        <?php echo method_field('put'); ?>

                        <?php echo e(csrf_field()); ?>

                        <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">


                            <div class=" col-md-6">
                                <label>نام کاربری</label>
                                <input class="form-control" type="text" id="national_code" name="national_code"
                                       <?php if(auth()->user()->role=='consult'): ?> value="<?php echo e($row->user->national_code); ?>"
                                       <?php else: ?> value="<?php echo e(auth()->user()->national_code); ?>" <?php endif; ?> readonly>
                                <br>
                                <label>رمز عبور قبلی</label>
                                <input type="password" name="old_password" placeholder="" class="form-control"
                                       autocomplete="off">



                            </div>

                            <div class="col-md-6">
                                <label>رمز جدید</label>
                                <input type="password" name="new_password" placeholder="" class="form-control"
                                       autocomplete="off">
                                <br>
                                <label>تکرار رمز جدید</label>
                                <input type="password" name="confirm_password" placeholder="" class="form-control"
                                       autocomplete="off">

                            </div>

                            <div class="form-group">
                                <br>
                                <div class="col-md-12 col-lg-12">
                                    <br>
                                    <button type="submit" class="btn btn-success btn-block">ذخیره</button>
                                </div>
                            </div>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\BookFair\resources\views/profile.blade.php ENDPATH**/ ?>